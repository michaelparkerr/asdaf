<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp_db' );

/** MySQL database username */
define( 'DB_USER', 'wp_user' );

/** MySQL database password */
define( 'DB_PASSWORD', 'hello' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'c@zx]Q`2aD2J%}aHr{jFj-pH6z}*Lh=i~*`_FI&oJfBpl/K-*B-MQ+5ZzM[69bJ:');
define('SECURE_AUTH_KEY',  'TY*kHc9k+^;AWn*KD&:p=G|-g8L7Rg >]_7^8Q(<;u|i cnqbOdWB`I)X7+)mdSz');
define('LOGGED_IN_KEY',    '@GA dLLDYb|F|K++)kF.o%SG+L$Q D;@+[Pm-x&D0FNR[[)3dG?h4>:`bYkEs2o]');
define('NONCE_KEY',        '#TRVeWL=+60o2)>gg2,Sx$7Vb05.5k%ude-/-ztn2en[=+OjQ+l1li,p-Cg(H+s+');
define('AUTH_SALT',        '+i52mI+|EzR- &%m]sxMGkfFoNEqZzG4)L@1Pi:BDg4?bIo8--TU]/A4lSc6iqIy');
define('SECURE_AUTH_SALT', 'P7mF+Hm.X8?F{[Fs209f1w@gJ&*!*vC}-WFzHd|Uh%q3b,cgn8%Xh4*K(:}V{!02');
define('LOGGED_IN_SALT',   '>5)GI+D~#eHr#Y|_q$Di<=|h^kLBu%.JJq,5<q5wQIRgK72_tg8wSyLKSSCHiT5!');
define('NONCE_SALT',       'aeP0D#llBX??k-6p(p6=5G;,BuJSa~H?_`T<Qup=@C2^OzMU^<,IS{tA@L):OdY3');
	
/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
